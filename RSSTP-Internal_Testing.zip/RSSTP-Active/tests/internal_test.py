import numpy as np
import pytest

from src.internal import Internal

obj = Internal(np.array([[(0,1,2,3,4)]], dtype = object),0)
# -------------------------------------------------------------Tests-------------------------------------------------------------------------------------------
def test_split():
    
    #-------------Transition matrix abnormal dimension check---------------------------
    
    """
   
    n = 0
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),()],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)


    assert (obj.split(n) == False)                                 
    

    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,),(1,6)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    assert (obj.split(n) == False)    

    n = 6
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,),(1,6)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    assert (obj.split(n) == False)     
    """
 #-------------Normal Tests ---------------------------
   
    n = 0
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = np.array([[(0,1),(2,3),(4,3),(0,1)],
                         [(1,2),(),(3,),(1,2)],
                         [(2,4),(1,2,3),(1,),(2,4)],
                         [(0,1),(2,3),(4,3),(0,1)]], dtype = object)
    assert (np.array_equal(obj.split(n) , expected))

    n = 1
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = np.array([[(0,1),(2,3),(4,3),(2,3)],
                         [(1,2),(),(3,),()],
                         [(2,4),(1,2,3),(1,),(1,2,3)],
                         [(1,2),(),(3,),()]], dtype = object)
    assert (np.array_equal(obj.split(n) , expected))
    
    n = 2
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = np.array([[(0,1),(2,3),(4,3),(4,3)],
                         [(1,2),(),(3,),(3,)],
                         [(2,4),(1,2,3),(1,),(1,)],
                         [(2,4),(1,2,3),(1,),(1,)]], dtype = object)
    assert (np.array_equal(obj.split(n) , expected))

def test_merge():

#-------------Abnormal Tests ---------------------------
    """
    n = 0
    m = 1
    obj.transition_matrix = np.array([[(0,1),(2,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    assert (obj.merge(n,m) == False)  

    n = 0
    m = 1
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,),()],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    assert (obj.merge(n,m) == False)  

    n = 7
    m = 1
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    assert (obj.merge(n,m) == False)  
   
    n = 1
    m = 1
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    assert (obj.merge(n,m) == False)  

    n = 1
    m = 8
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    assert (obj.merge(n,m) == False)  
    """

#-------------Normal Tests ---------------------------
 

    n = 0
    m = 1
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = np.array([[(0,1,2,3),(3,4)],
                         [(1,2,3,4),(1,)]], dtype = object)
    assert (np.array_equal(obj.merge(n,m) , expected ))
    
    n = 0
    m = 2
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object) 

    expected = np.array([[(0,1,2,3,4),(1,2,3)],
                         [(1,2,3),()]], dtype = object)
    assert (np.array_equal(obj.merge(n,m) ,expected ))

    n = 1
    m = 2
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = np.array([[(0,1),(2,3,4)],
                         [(1,2,4),(1,2,3)]], dtype = object)
    assert (np.array_equal(obj.merge(n,m) , expected ))

def test_add():
#-------------Abnormal Tests ---------------------------
    """
    n = 0
    m = 1
    k = 0
    obj.transition_matrix = np.array([[(0,1),(2,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)
     
    assert (obj.add(n,m,k) == False)  
    
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3),()],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)
     
    assert (obj.add(n,m,k) == False)  
    
    n = 0
    m = 8
    k = 0
    obj.transition_matrix = np.array([[(0,1),(2,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)
     
    assert (obj.add(n,m,k) == False)  

    n = 8
    m = 1
    k = 0
    obj.transition_matrix = np.array([[(0,1),(2,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)
     
    assert (obj.add(n,m,k) == False)  

    """

#-------------Normal Tests ---------------------------
    n = 0
    m = 1
    k = 0
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = np.array([[(0,1),(0,2,3),(4,3)],
                         [(1,2),(),(3,)],
                         [(2,4),(1,2,3),(1,)]], dtype = object)
    assert (np.array_equal(obj.add(n,m,k) , expected))

    n = 1
    m = 1
    k = 3
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = np.array([[(0,1),(2,3),(4,3)],
                         [(1,2),(3,),(3,)],
                         [(2,4),(1,2,3),(1,)]], dtype = object)
    assert (np.array_equal(obj.add(n,m,k) , expected ))

    n = 2
    m = 2
    k = 0
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = np.array([[(0,1),(2,3),(4,3)],
                         [(1,2),(),(3,)],
                         [(2,4),(1,2,3),(0,1)]], dtype = object)
    assert (np.array_equal(obj.add(n,m,k) , expected))

def test_delete():
#-------------Abnormal Tests ---------------------------
    """
     n = 0
    m = 1
    k = 0
    obj.transition_matrix = np.array([[(0,1),(2,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)
     
    assert (obj.delete(n,m,k) == False)  
    
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3),()],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)
     
    assert (obj.delete(n,m,k) == False)  
    
    n = 0
    m = 8
    k = 0
    obj.transition_matrix = np.array([[(0,1),(2,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)
     
    assert (obj.delete(n,m,k) == False)  

    n = 8
    m = 1
    k = 0
    obj.transition_matrix = np.array([[(0,1),(2,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)
     
    assert (obj.delete(n,m,k) == False)  


    """
#-------------Normal Tests ---------------------------

    n = 0
    m = 0
    k = 0
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = np.array([[(1,),(2,3),(4,3)],
                         [(1,2),(),(3,)],
                         [(2,4),(1,2,3),(1,)]], dtype = object)
    assert (np.array_equal(obj.delete(n,m,k) , expected))

    n = 1
    m = 2
    k = 3
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = np.array([[(0,1),(2,3),(4,3)],
                         [(1,2),(),()],
                         [(2,4),(1,2,3),(1,)]], dtype = object)
    assert (np.array_equal(obj.delete(n,m,k) , expected))

    n = 2
    m = 1
    k = 2
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = np.array([[(0,1),(2,3),(4,3)],
                         [(1,2),(),(3,)],
                         [(2,4),(1,3),(1,)]], dtype = object)
    assert (np.array_equal(obj.delete(n,m,k) , expected))

    n = 2
    m = 1
    k = 0
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = np.array([[(0,1),(2,3),(4,3)],
                         [(1,2),(),(3,)],
                         [(2,4),(1,2,3),(1,)]], dtype = object)
    assert (np.array_equal(obj.delete(n,m,k) , expected))

def test_transition():
#-------------Abnormal Tests ---------------------------
    """
    k = 0
    obj.current_state = 0
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3)]], dtype = object)

    expected = (-2,)
    assert (obj.transition(k) in expected)
    
    k = 0
    obj.current_state = 0
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3),()],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = (-2,)
    assert (obj.transition(k) in expected)
    
    k = 0
    obj.current_state = 7
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3),()],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = (-2,)
    assert (obj.transition(k) in expected)


    """

#-------------Normal Tests ---------------------------

    k = 0
    obj.current_state = 0
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = (0,)
    assert (obj.transition(k) in expected)

    k = 3
    obj.current_state = 0
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = (1,2)
    assert (obj.transition(k) in expected)

    k = 2
    obj.current_state = 2
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = (0,1)
    assert (obj.transition(k) in expected)

    k = 0
    obj.current_state = 1
    obj.transition_matrix = np.array([[(0,1),(2,3),(4,3)],
                                      [(1,2),(),(3,)],
                                      [(2,4),(1,2,3),(1,)]], dtype = object)

    expected = (-1,)
    assert (obj.transition(k) in expected)
    
retcode = pytest.main()
