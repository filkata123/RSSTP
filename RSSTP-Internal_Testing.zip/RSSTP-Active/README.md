# RSSTP
Repository for the Robotic Sensorimotor System Testing Platform (RSSTP) project, started in the University of Oulu.

Current used libraries: numpy, shapely, pytest #TODO: add a setup.py file